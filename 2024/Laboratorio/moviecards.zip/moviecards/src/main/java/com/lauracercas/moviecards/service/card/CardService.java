package com.lauracercas.moviecards.service.card;

import com.lauracercas.moviecards.model.Card;

/**
 * Autor: Laura Cercas Ramos
 * Proyecto: TFM Integración Continua con GitHub Actions
 * Fecha: 04/06/2024
 */
public interface CardService {

    String registerActorInMovie(Card card);

}
